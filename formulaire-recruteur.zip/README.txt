Formulaire Recruteur - RecruPPrivé.CI

- Ce fichier formulaire-recruteur.html est prêt à être téléversé sur votre site.
- Vérifiez que le lien 'action' dans le formulaire pointe vers votre URL Formspree valide.
- Pour utiliser, créez un lien sur votre site vers ce fichier, par exemple :
  <a href="formulaire-recruteur.html">Demande de recrutement</a>
- Contact WhatsApp pour assistance : 05 46 33 47 81
